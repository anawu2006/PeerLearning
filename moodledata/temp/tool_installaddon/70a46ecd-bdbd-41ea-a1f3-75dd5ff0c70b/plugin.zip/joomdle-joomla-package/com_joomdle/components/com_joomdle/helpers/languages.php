<?php // $Id: languages.php,v 1.7 2006/12/11 10:07:47 jamiesensei Exp $



$LANGUAGES = array (

"aa" => "Afar",

"ab" => "Abkhazian",

"ae" => "Avestan",

"af" => "Afrikaans",

"am" => "Amharic",

"ar" => "Arabic",

"as" => "Assamese",

"ay" => "Aymara",

"az" => "Azerbaijani",

"ba" => "Bashkir",

"be" => "Belarussian",

"bg" => "Bulgarian",

"bh" => "Bihari",

"bi" => "Bislama",

"bn" => "Bengali",

"bo" => "Tibetan",

"br" => "Breton",

"bs" => "Bosnian",

"ca" => "Catalan",

"ce" => "Chechen",

"ch" => "Chamorro",

"co" => "Corsican",

"cs" => "Czech",

"cu" => "Church Slavic",

"cv" => "Chuvash",

"cy" => "Welsh",

"da" => "Danish",

"de" => "German",

"dz" => "Dzongkha",

"el" => "Modern Greek",

"en" => "English",

"eo" => "Esperanto",

"es" => "Spanish",

"et" => "Estonian",

"eu" => "Basque",

"fa" => "Persian",

"fi" => "Finnish",

"fj" => "Fijian",

"fo" => "Faroese",

"fr" => "French",

"fy" => "Frisian",

"ga" => "Irish",

"gd" => "Scots Gaelic",

"gl" => "Gallegan ",

"gn" => "Guarani",

"gu" => "Gujarati",

"gv" => "Manx",

"ha" => "Hausa",

"he" => "Hebrew",

"hi" => "Hindi",

"ho" => "Hiri Motu",

"hr" => "Croatian",

"hu" => "Hungarian",

"hy" => "Armenian",

"hz" => "Herero",

"ia" => "Interlingua",

"id" => "Indonesian ",

"ie" => "Interlingue",

"ik" => "Inupiaq ",

"is" => "Icelandic",

"it" => "Italian",

"iu" => "Inuktitut",

"ja" => "Japanese",

"jw" => "Javanese",

"ka" => "Georgian",

"ki" => "Kikuyu",

"kj" => "Kuanyama",

"kk" => "Kazakh",

"kl" => "Kalaallisut",

"km" => "Khmer",

"kn" => "Kannada",

"ko" => "Korean",

"ks" => "Kashmiri",

"ku" => "Kurdish",

"kv" => "Komi",

"kw" => "Cornish",

"ky" => "Kirghiz",

"la" => "Latin",

"lb" => "Luxembourgish",

"ln" => "Lingala",

"lo" => "Lao ",

"lt" => "Lithuanian",

"lv" => "Latvian ",

"mg" => "Malagasy",

"mh" => "Marshall",

"mi" => "Maori",

"mk" => "Macedonian",

"ml" => "Malayalam",

"mn" => "Mongolian",

"mo" => "Moldavian",

"mr" => "Marathi",

"ms" => "Malay",

"mt" => "Maltese",

"my" => "Burmese",

"na" => "Nauru",

"nb" => "Norwegian Bokm�l",

"nd" => "Ndebele, North",

"ne" => "Nepali",

"ng" => "Ndonga",

"nl" => "Dutch",

"nn" => "Norwegian Nynorsk",

"no" => "Norwegian",

"nr" => "Ndebele, South",

"nv" => "Navajo",

"ny" => "Chichewa",

"oc" => "Occitan",

"om" => "Oromo",

"or" => "Oriya",

"os" => "Ossetian",

"pa" => "Panjabi",

"ph" => "Filipino",

"pi" => "Pali",

"pl" => "Polish",

"ps" => "Pushto",

"pt" => "Portuguese",

"pt_br" => "Portuguese (Brazil)",

"qu" => "Quechua",

"rm" => "Raeto-Romance",

"rn" => "Rundi",

"ro" => "Romanian",

"ru" => "Russian",

"rw" => "Kinyarwanda",

"sa" => "Sanskrit",

"sc" => "Sardinian",

"sd" => "Sindhi",

"se" => "Northern Sami",

"sg" => "Sangho",

"si" => "Sinhalese",

"sk" => "Slovak",

"sl" => "Slovenian",

"sm" => "Samoan",

"sn" => "Shona",

"so" => "Somali",

"sq" => "Albanian",

"sr" => "Serbian",

"ss" => "Swati",

"st" => "Sesotho",

"su" => "Sundanese",

"sv" => "Swedish",

"sw" => "Swahili",

"ta" => "Tamil",

"te" => "Telugu",

"tg" => "Tajik",

"th" => "Thai",

"tk" => "Turkmen",

"tl" => "Tagalog",

"tn" => "Tswana",

"tr" => "Turkish",

"ts" => "Tsonga",

"tt" => "Tatar",

"tw" => "Twi",

"ty" => "Tahitian",

"ug" => "Uighur",

"uk" => "Ukrainian",

"ur" => "Urdu",

"uz" => "Uzbek",

"vi" => "Vietnamese",

"vo" => "Volap",

"wo" => "Wolof",

"xh" => "Xhosa",

"yi" => "Yiddish",

"za" => "Zhuang",

"zh" => "Chinese",

"zu" => "Zulu");



?>