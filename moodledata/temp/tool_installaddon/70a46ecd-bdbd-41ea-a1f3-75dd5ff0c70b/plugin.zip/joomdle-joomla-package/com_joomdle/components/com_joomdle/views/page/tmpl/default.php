<?php defined('_JEXEC') or die('Restricted access'); ?>
<div id="joomdle">
    <h1>
                <?php echo $this->page['name']; ?>
    </h1>
    <div class="moodlepage">
    <?php echo $this->page['content']; ?>
    </div>
</div>
